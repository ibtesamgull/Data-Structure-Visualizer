
import javax.swing.*;
import javax.swing.*;

public class DataStructureVisualizer {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}