import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class GraphVisualizerFrame extends JFrame {
    private Map<Integer, List<Integer>> graph;
    private Map<Integer, Point> nodePositions;
    private GraphPanel graphPanel;
    private JTextField fromField, toField, nodeField;
    private int nodeCount = 0;

    public GraphVisualizerFrame() {
        graph = new HashMap<>();
        nodePositions = new HashMap<>();
        setTitle("Graph Operations Visualizer");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(240, 240, 245));

        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(220, 20, 60));
        JLabel titleLabel = new JLabel("Graph Operations (Directed Graph)");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);

        // Visualization Panel
        graphPanel = new GraphPanel();

        // Control Panel
        JPanel controlPanel = new JPanel();
        controlPanel.setBackground(new Color(240, 240, 245));
        controlPanel.setLayout(new GridLayout(2, 1, 5, 5));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Input Panel
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        inputPanel.setBackground(new Color(240, 240, 245));

        inputPanel.add(new JLabel("Node:"));
        nodeField = new JTextField(6);
        inputPanel.add(nodeField);

        inputPanel.add(new JLabel("From:"));
        fromField = new JTextField(6);
        inputPanel.add(fromField);

        inputPanel.add(new JLabel("To:"));
        toField = new JTextField(6);
        inputPanel.add(toField);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 5));
        buttonPanel.setBackground(new Color(240, 240, 245));

        JButton addNodeButton = createButton("Add Node", new Color(60, 179, 113));
        addNodeButton.addActionListener(e -> addNode());

        JButton addEdgeButton = createButton("Add Edge", new Color(70, 130, 180));
        addEdgeButton.addActionListener(e -> addEdge());

        JButton removeEdgeButton = createButton("Remove Edge", new Color(255, 140, 0));
        removeEdgeButton.addActionListener(e -> removeEdge());

        JButton bfsButton = createButton("BFS", new Color(147, 112, 219));
        bfsButton.addActionListener(e -> performBFS());

        JButton dfsButton = createButton("DFS", new Color(255, 99, 71));
        dfsButton.addActionListener(e -> performDFS());

        JButton clearButton = createButton("Clear Graph", new Color(128, 128, 128));
        clearButton.addActionListener(e -> clear());

        JButton backButton = createButton("Back", new Color(105, 105, 105));
        backButton.addActionListener(e -> {
            NonLinearDSFrame nonLinearFrame = new NonLinearDSFrame();
            nonLinearFrame.setVisible(true);
            dispose();
        });

        buttonPanel.add(addNodeButton);
        buttonPanel.add(addEdgeButton);
        buttonPanel.add(removeEdgeButton);
        buttonPanel.add(bfsButton);
        buttonPanel.add(dfsButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(backButton);

        controlPanel.add(inputPanel);
        controlPanel.add(buttonPanel);

        add(titlePanel, BorderLayout.NORTH);
        add(graphPanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);
    }

    private JButton createButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 11));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        return button;
    }

    private void addNode() {
        try {
            int node = Integer.parseInt(nodeField.getText().trim());

            if (graph.containsKey(node)) {
                JOptionPane.showMessageDialog(this, "Node " + node + " already exists");
                return;
            }

            graph.put(node, new ArrayList<>());

            // Position nodes in a circle
            int centerX = graphPanel.getWidth() / 2;
            int centerY = graphPanel.getHeight() / 2;
            int radius = 200;
            double angle = (2 * Math.PI * nodeCount) / Math.max(8, graph.size());
            int x = centerX + (int)(radius * Math.cos(angle));
            int y = centerY + (int)(radius * Math.sin(angle));

            nodePositions.put(node, new Point(x, y));
            nodeCount++;

            graphPanel.repaint();
            nodeField.setText("");
            JOptionPane.showMessageDialog(this, "Added node " + node);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid integer",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addEdge() {
        try {
            int from = Integer.parseInt(fromField.getText().trim());
            int to = Integer.parseInt(toField.getText().trim());

            if (!graph.containsKey(from) || !graph.containsKey(to)) {
                JOptionPane.showMessageDialog(this, "Both nodes must exist in the graph",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (graph.get(from).contains(to)) {
                JOptionPane.showMessageDialog(this, "Edge already exists");
                return;
            }

            graph.get(from).add(to);
            graphPanel.repaint();
            fromField.setText("");
            toField.setText("");
            JOptionPane.showMessageDialog(this, "Added edge from " + from + " to " + to);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid integers",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removeEdge() {
        try {
            int from = Integer.parseInt(fromField.getText().trim());
            int to = Integer.parseInt(toField.getText().trim());

            if (!graph.containsKey(from)) {
                JOptionPane.showMessageDialog(this, "Source node doesn't exist",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (graph.get(from).remove(Integer.valueOf(to))) {
                graphPanel.repaint();
                fromField.setText("");
                toField.setText("");
                JOptionPane.showMessageDialog(this, "Removed edge from " + from + " to " + to);
            } else {
                JOptionPane.showMessageDialog(this, "Edge doesn't exist");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid integers",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void performBFS() {
        if (graph.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Graph is empty");
            return;
        }

        try {
            int start = Integer.parseInt(nodeField.getText().trim());
            if (!graph.containsKey(start)) {
                JOptionPane.showMessageDialog(this, "Start node doesn't exist",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            StringBuilder result = new StringBuilder("BFS Traversal from " + start + ":\n");
            Set<Integer> visited = new HashSet<>();
            Queue<Integer> queue = new LinkedList<>();

            queue.offer(start);
            visited.add(start);

            while (!queue.isEmpty()) {
                int node = queue.poll();
                result.append(node).append(" ");

                for (int neighbor : graph.get(node)) {
                    if (!visited.contains(neighbor)) {
                        visited.add(neighbor);
                        queue.offer(neighbor);
                    }
                }
            }

            nodeField.setText("");
            JOptionPane.showMessageDialog(this, result.toString(),
                    "BFS Result", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid start node",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void performDFS() {
        if (graph.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Graph is empty");
            return;
        }

        try {
            int start = Integer.parseInt(nodeField.getText().trim());
            if (!graph.containsKey(start)) {
                JOptionPane.showMessageDialog(this, "Start node doesn't exist",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            StringBuilder result = new StringBuilder("DFS Traversal from " + start + ":\n");
            Set<Integer> visited = new HashSet<>();
            dfsHelper(start, visited, result);

            nodeField.setText("");
            JOptionPane.showMessageDialog(this, result.toString(),
                    "DFS Result", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid start node",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void dfsHelper(int node, Set<Integer> visited, StringBuilder result) {
        visited.add(node);
        result.append(node).append(" ");

        for (int neighbor : graph.get(node)) {
            if (!visited.contains(neighbor)) {
                dfsHelper(neighbor, visited, result);
            }
        }
    }

    private void clear() {
        graph.clear();
        nodePositions.clear();
        nodeCount = 0;
        graphPanel.repaint();
        JOptionPane.showMessageDialog(this, "Graph cleared");
    }

    class GraphPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            setBackground(Color.WHITE);

            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (graph.isEmpty()) {
                g2d.setColor(Color.GRAY);
                g2d.setFont(new Font("Arial", Font.ITALIC, 18));
                g2d.drawString("Graph is empty. Add nodes and edges to visualize.", 220, 300);
                return;
            }

            int nodeRadius = 25;

            // Draw edges first
            g2d.setStroke(new BasicStroke(2));
            for (Map.Entry<Integer, List<Integer>> entry : graph.entrySet()) {
                int from = entry.getKey();
                Point fromPos = nodePositions.get(from);

                for (int to : entry.getValue()) {
                    Point toPos = nodePositions.get(to);

                    // Draw line
                    g2d.setColor(Color.BLACK);
                    g2d.drawLine(fromPos.x, fromPos.y, toPos.x, toPos.y);

                    // Draw arrow
                    double angle = Math.atan2(toPos.y - fromPos.y, toPos.x - fromPos.x);
                    int arrowX = (int)(toPos.x - nodeRadius * Math.cos(angle));
                    int arrowY = (int)(toPos.y - nodeRadius * Math.sin(angle));

                    int[] xPoints = {
                            arrowX,
                            (int)(arrowX - 10 * Math.cos(angle - Math.PI / 6)),
                            (int)(arrowX - 10 * Math.cos(angle + Math.PI / 6))
                    };
                    int[] yPoints = {
                            arrowY,
                            (int)(arrowY - 10 * Math.sin(angle - Math.PI / 6)),
                            (int)(arrowY - 10 * Math.sin(angle + Math.PI / 6))
                    };

                    g2d.fillPolygon(xPoints, yPoints, 3);
                }
            }

            // Draw nodes
            for (Map.Entry<Integer, Point> entry : nodePositions.entrySet()) {
                int node = entry.getKey();
                Point pos = entry.getValue();

                // Node circle
                g2d.setColor(new Color(220, 20, 60));
                g2d.fillOval(pos.x - nodeRadius, pos.y - nodeRadius, nodeRadius * 2, nodeRadius * 2);
                g2d.setColor(Color.BLACK);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawOval(pos.x - nodeRadius, pos.y - nodeRadius, nodeRadius * 2, nodeRadius * 2);

                // Node value
                g2d.setColor(Color.WHITE);
                g2d.setFont(new Font("Arial", Font.BOLD, 16));
                String value = String.valueOf(node);
                FontMetrics fm = g2d.getFontMetrics();
                int textX = pos.x - fm.stringWidth(value) / 2;
                int textY = pos.y + fm.getAscent() / 2 - 2;
                g2d.drawString(value, textX, textY);
            }

            // Draw legend
            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font("Arial", Font.BOLD, 14));
            g2d.drawString("Nodes: " + graph.size(), 20, 30);
        }
    }
}
