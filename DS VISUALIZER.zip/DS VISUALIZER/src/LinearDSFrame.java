import javax.swing.*;
import java.awt.*;

public class LinearDSFrame extends JFrame {

    public LinearDSFrame() {
        setTitle("Linear Data Structures");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(240, 240, 245));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(240, 240, 245));
        JLabel titleLabel = new JLabel("Linear Data Structures");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(60, 179, 113));
        titlePanel.add(titleLabel);

        // Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 1, 15, 15));
        buttonPanel.setBackground(new Color(240, 240, 245));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));



        // Stack Operations Button
        JButton stackButton = createStyledButton("Stack Operations", new Color(147, 112, 219));
        stackButton.addActionListener(e -> {
            StackVisualizerFrame stackFrame = new StackVisualizerFrame();
            stackFrame.setVisible(true);
            dispose();
        });

        // Queue Operations Button
        JButton queueButton = createStyledButton("Queue Operations", new Color(255, 165, 0));
        queueButton.addActionListener(e -> {
            QueueVisualizerFrame queueFrame = new QueueVisualizerFrame();
            queueFrame.setVisible(true);
            dispose();
        });

        // LinkedList Operations Button
        JButton linkedListButton = createStyledButton("LinkedList Operations", new Color(46, 139, 87));
        linkedListButton.addActionListener(e -> {
            LinkedListVisualizerFrame llFrame = new LinkedListVisualizerFrame();
            llFrame.setVisible(true);
            dispose();
        });

        // Back Button
        JButton backButton = createStyledButton("Back to Main Menu", new Color(128, 128, 128));
        backButton.addActionListener(e -> {
            MainMenuFrame mainMenu = new MainMenuFrame("User");
            mainMenu.setVisible(true);
            dispose();
        });


        buttonPanel.add(stackButton);
        buttonPanel.add(queueButton);
        buttonPanel.add(linkedListButton);
        buttonPanel.add(backButton);

        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        add(mainPanel);
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 15));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(300, 55));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });

        return button;
    }
}