import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;

public class LinkedListVisualizerFrame extends JFrame {
    private LinkedList<Integer> linkedList;
    private LinkedListPanel listPanel;
    private JTextField inputField;
    private JTextField positionField;

    public LinkedListVisualizerFrame() {
        linkedList = new LinkedList<>();
        setTitle("LinkedList Operations Visualizer");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(240, 240, 245));

        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(46, 139, 87));
        JLabel titleLabel = new JLabel("LinkedList Operations");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);

        // Visualization Panel
        listPanel = new LinkedListPanel();

        // Control Panel
        JPanel controlPanel = new JPanel();
        controlPanel.setBackground(new Color(240, 240, 245));
        controlPanel.setLayout(new GridLayout(2, 1, 5, 5));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Input Panel
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        inputPanel.setBackground(new Color(240, 240, 245));

        inputPanel.add(new JLabel("Value:"));
        inputField = new JTextField(8);
        inputPanel.add(inputField);

        inputPanel.add(new JLabel("Position:"));
        positionField = new JTextField(8);
        inputPanel.add(positionField);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 5));
        buttonPanel.setBackground(new Color(240, 240, 245));

        JButton insertFirstButton = createButton("Insert First", new Color(60, 179, 113));
        insertFirstButton.addActionListener(e -> insertFirst());

        JButton insertLastButton = createButton("Insert Last", new Color(70, 130, 180));
        insertLastButton.addActionListener(e -> insertLast());

        JButton insertAtButton = createButton("Insert At Pos", new Color(147, 112, 219));
        insertAtButton.addActionListener(e -> insertAtPosition());

        JButton deleteFirstButton = createButton("Delete First", new Color(220, 20, 60));
        deleteFirstButton.addActionListener(e -> deleteFirst());

        JButton deleteLastButton = createButton("Delete Last", new Color(255, 69, 0));
        deleteLastButton.addActionListener(e -> deleteLast());

        JButton searchButton = createButton("Search", new Color(255, 140, 0));
        searchButton.addActionListener(e -> search());

        JButton clearButton = createButton("Clear", new Color(128, 128, 128));
        clearButton.addActionListener(e -> clear());

        JButton backButton = createButton("Back", new Color(105, 105, 105));
        backButton.addActionListener(e -> {
            LinearDSFrame linearFrame = new LinearDSFrame();
            linearFrame.setVisible(true);
            dispose();
        });

        buttonPanel.add(insertFirstButton);
        buttonPanel.add(insertLastButton);
        buttonPanel.add(insertAtButton);
        buttonPanel.add(deleteFirstButton);
        buttonPanel.add(deleteLastButton);
        buttonPanel.add(searchButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(backButton);

        controlPanel.add(inputPanel);
        controlPanel.add(buttonPanel);

        add(titlePanel, BorderLayout.NORTH);
        add(listPanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);
    }

    private JButton createButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 11));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        return button;
    }

    private void insertFirst() {
        try {
            int value = Integer.parseInt(inputField.getText().trim());
            linkedList.addFirst(value);
            listPanel.repaint();
            inputField.setText("");
            JOptionPane.showMessageDialog(this, "Inserted " + value + " at the beginning");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid integer",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void insertLast() {
        try {
            int value = Integer.parseInt(inputField.getText().trim());
            linkedList.addLast(value);
            listPanel.repaint();
            inputField.setText("");
            JOptionPane.showMessageDialog(this, "Inserted " + value + " at the end");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid integer",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void insertAtPosition() {
        try {
            int value = Integer.parseInt(inputField.getText().trim());
            int position = Integer.parseInt(positionField.getText().trim());

            if (position < 0 || position > linkedList.size()) {
                JOptionPane.showMessageDialog(this, "Invalid position",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            linkedList.add(position, value);
            listPanel.repaint();
            inputField.setText("");
            positionField.setText("");
            JOptionPane.showMessageDialog(this, "Inserted " + value + " at position " + position);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid integers Only",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteFirst() {
        if (linkedList.isEmpty()) {
            JOptionPane.showMessageDialog(this, " Your LinkedList is empty",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int value = linkedList.removeFirst();
        listPanel.repaint();
        JOptionPane.showMessageDialog(this, "Deleted " + value + " from the beginning");
    }

    private void deleteLast() {
        if (linkedList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "LinkedList is empty",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int value = linkedList.removeLast();
        listPanel.repaint();
        JOptionPane.showMessageDialog(this, "Deleted " + value + " from the end");
    }

    private void search() {
        try {
            int value = Integer.parseInt(inputField.getText().trim());
            int index = linkedList.indexOf(value);

            if (index != -1) {
                JOptionPane.showMessageDialog(this, "Found " + value + " at position " + index);
            } else {
                JOptionPane.showMessageDialog(this, value + " not found in the list");
            }
            inputField.setText("");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid integer",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clear() {
        linkedList.clear();
        listPanel.repaint();
        JOptionPane.showMessageDialog(this, "LinkedList cleared");
    }

    class LinkedListPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            setBackground(Color.WHITE);

            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (linkedList.isEmpty()) {
                g2d.setColor(Color.GRAY);
                g2d.setFont(new Font("Arial", Font.ITALIC, 18));
                g2d.drawString("LinkedList is empty. Insert elements to visualize.", 220, 250);

                // Draw NULL
                g2d.setColor(Color.RED);
                g2d.setFont(new Font("Arial", Font.BOLD, 16));
                g2d.drawString("HEAD → NULL", 350, 300);
                return;
            }

            int nodeWidth = 80;
            int nodeHeight = 50;
            int arrowLength = 40;
            int startX = 50;
            int startY = 150;
            int nodesPerRow = 8;

            // Draw HEAD pointer
            g2d.setColor(Color.BLUE);
            g2d.setFont(new Font("Arial", Font.BOLD, 14));
            g2d.drawString("HEAD", startX - 10, startY - 15);

            for (int i = 0; i < linkedList.size(); i++) {
                int row = i / nodesPerRow;
                int col = i % nodesPerRow;
                int x = startX + col * (nodeWidth + arrowLength);
                int y = startY + row * (nodeHeight + 60);

                // Draw node
                g2d.setColor(new Color(46, 139, 87));
                g2d.fillRect(x, y, nodeWidth, nodeHeight);
                g2d.setColor(Color.BLACK);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawRect(x, y, nodeWidth, nodeHeight);

                // Divide node into data and next sections
                int dividerX = x + nodeWidth * 2 / 3;
                g2d.drawLine(dividerX, y, dividerX, y + nodeHeight);

                // Draw value
                g2d.setColor(Color.WHITE);
                g2d.setFont(new Font("Arial", Font.BOLD, 16));
                String value = String.valueOf(linkedList.get(i));
                FontMetrics fm = g2d.getFontMetrics();
                int textX = x + (nodeWidth * 2 / 3 - fm.stringWidth(value)) / 2;
                int textY = y + (nodeHeight + fm.getAscent()) / 2 - 2;
                g2d.drawString(value, textX, textY);

                // Draw next pointer arrow
                if (i < linkedList.size() - 1 && col < nodesPerRow - 1) {
                    g2d.setColor(Color.BLACK);
                    int arrowStartX = x + nodeWidth;
                    int arrowStartY = y + nodeHeight / 2;
                    int arrowEndX = arrowStartX + arrowLength;

                    g2d.drawLine(arrowStartX, arrowStartY, arrowEndX, arrowStartY);
                    g2d.fillPolygon(
                            new int[]{arrowEndX, arrowEndX - 6, arrowEndX - 6},
                            new int[]{arrowStartY, arrowStartY - 4, arrowStartY + 4},
                            3
                    );
                } else if (i < linkedList.size() - 1) {
                    // Draw curved arrow to next row
                    g2d.setColor(Color.BLACK);
                    int arrowStartX = x + nodeWidth / 2;
                    int arrowStartY = y + nodeHeight;
                    g2d.drawLine(arrowStartX, arrowStartY, arrowStartX, arrowStartY + 30);
                }

                // Draw NULL at the end
                if (i == linkedList.size() - 1) {
                    g2d.setColor(Color.RED);
                    g2d.setFont(new Font("Arial", Font.BOLD, 14));
                    int nullX = x + nodeWidth + 10;
                    int nullY = y + nodeHeight / 2 + 5;
                    g2d.drawString("→ NULL", nullX, nullY);
                }

                // Draw position label
                g2d.setColor(Color.GRAY);
                g2d.setFont(new Font("Arial", Font.PLAIN, 11));
                g2d.drawString("[" + i + "]", x + 25, y + nodeHeight + 15);
            }

            // Size indicator
            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font("Arial", Font.BOLD, 16));
            g2d.drawString("Size: " + linkedList.size(), 30, 30);
        }
    }
}
