import javax.swing.*;
import java.awt.*;

public class NonLinearDSFrame extends JFrame {

    public NonLinearDSFrame() {
        setTitle("Non-Linear Data Structures");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(240, 240, 245));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(240, 240, 245));
        JLabel titleLabel = new JLabel("Non-Linear Data Structures");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(255, 140, 0));
        titlePanel.add(titleLabel);

        // Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(3, 1, 15, 15));
        buttonPanel.setBackground(new Color(240, 240, 245));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        // Tree Operations Button
        JButton treeButton = createStyledButton("Tree Operations", new Color(34, 139, 34));
        treeButton.addActionListener(e -> {
            TreeVisualizerFrame treeFrame = new TreeVisualizerFrame();
            treeFrame.setVisible(true);
            dispose();
        });

        // Graph Operations Button
        JButton graphButton = createStyledButton("Graph Operations", new Color(220, 20, 60));
        graphButton.addActionListener(e -> {
            GraphVisualizerFrame graphFrame = new GraphVisualizerFrame();
            graphFrame.setVisible(true);
            dispose();
        });

        // Back Button
        JButton backButton = createStyledButton("Back to Main Menu", new Color(128, 128, 128));
        backButton.addActionListener(e -> {
            MainMenuFrame mainMenu = new MainMenuFrame("User"  );
            mainMenu.setVisible(true);
            dispose();
        });

        buttonPanel.add(treeButton);
        buttonPanel.add(graphButton);
        buttonPanel.add(backButton);

        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        add(mainPanel);
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(300, 60));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });

        return button;
    }
}
