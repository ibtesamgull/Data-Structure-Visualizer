import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;
import java.util.Queue;

public class QueueVisualizerFrame extends JFrame {
    private Queue<Integer> queue;
    private QueuePanel queuePanel;
    private JTextField inputField;
    private static final int MAX_SIZE = 12;

    public QueueVisualizerFrame() {
        queue = new LinkedList<>();
        setTitle("Queue Operations Visualizer");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(240, 240, 245));

        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(255, 165, 0));
        JLabel titleLabel = new JLabel("Queue Operations (FIFO - First In First Out)");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);

        // Visualization Panel
        queuePanel = new QueuePanel();

        // Control Panel
        JPanel controlPanel = new JPanel();
        controlPanel.setBackground(new Color(240, 240, 245));
        controlPanel.setLayout(new GridLayout(2, 1, 5, 5));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Input Panel
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        inputPanel.setBackground(new Color(240, 240, 245));

        inputPanel.add(new JLabel("Value:"));
        inputField = new JTextField(10);
        inputPanel.add(inputField);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setBackground(new Color(240, 240, 245));

        JButton enqueueButton = createButton("Enqueue (Insert)", new Color(60, 179, 113));
        enqueueButton.addActionListener(e -> enqueue());

        JButton dequeueButton = createButton("Dequeue (Remove)", new Color(220, 20, 60));
        dequeueButton.addActionListener(e -> dequeue());

        JButton peekButton = createButton("Peek (View Front)", new Color(70, 130, 180));
        peekButton.addActionListener(e -> peek());

        JButton clearButton = createButton("Clear Queue", new Color(128, 128, 128));
        clearButton.addActionListener(e -> clear());

        JButton backButton = createButton("Back", new Color(105, 105, 105));
        backButton.addActionListener(e -> {
            LinearDSFrame linearFrame = new LinearDSFrame();
            linearFrame.setVisible(true);
            dispose();
        });

        buttonPanel.add(enqueueButton);
        buttonPanel.add(dequeueButton);
        buttonPanel.add(peekButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(backButton);

        controlPanel.add(inputPanel);
        controlPanel.add(buttonPanel);

        add(titlePanel, BorderLayout.NORTH);
        add(queuePanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);
    }

    private JButton createButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        return button;
    }

    private void enqueue() {
        try {
            if (queue.size() >= MAX_SIZE) {
                JOptionPane.showMessageDialog(this, "Queue is full! Maximum size is " + MAX_SIZE,
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int value = Integer.parseInt(inputField.getText().trim());
            queue.offer(value);
            queuePanel.repaint();
            inputField.setText("");
            JOptionPane.showMessageDialog(this, "Enqueued " + value + " to queue");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid integer",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void dequeue() {
        if (queue.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Queue is empty! Nothing to dequeue",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int value = queue.poll();
        queuePanel.repaint();
        JOptionPane.showMessageDialog(this, "Dequeued " + value + " from queue");
    }

    private void peek() {
        if (queue.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Queue is empty",
                    "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int value = queue.peek();
        JOptionPane.showMessageDialog(this, "Front element: " + value);
    }

    private void clear() {
        queue.clear();
        queuePanel.repaint();
        JOptionPane.showMessageDialog(this, "Queue cleared");
    }

    class QueuePanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            setBackground(Color.WHITE);

            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (queue.isEmpty()) {
                g2d.setColor(Color.GRAY);
                g2d.setFont(new Font("Arial", Font.ITALIC, 18));
                g2d.drawString("Queue is empty. Enqueue elements to visualize.", 240, 250);
                return;
            }

            int boxSize = 60;
            int spacing = 10;
            int startX = 50;
            int centerY = getHeight() / 2 - boxSize / 2;

            Integer[] elements = queue.toArray(new Integer[0]);

            // Draw queue elements from front to rear
            for (int i = 0; i < elements.length; i++) {
                int x = startX + i * (boxSize + spacing);

                // Box
                g2d.setColor(new Color(255, 165, 0));
                g2d.fillRect(x, centerY, boxSize, boxSize);

                // Border
                g2d.setColor(Color.BLACK);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawRect(x, centerY, boxSize, boxSize);

                // Value
                g2d.setColor(Color.WHITE);
                g2d.setFont(new Font("Arial", Font.BOLD, 18));
                String value = String.valueOf(elements[i]);
                FontMetrics fm = g2d.getFontMetrics();
                int textX = x + (boxSize - fm.stringWidth(value)) / 2;
                int textY = centerY + (boxSize + fm.getAscent()) / 2 - 2;
                g2d.drawString(value, textX, textY);

                // Arrow between elements
                if (i < elements.length - 1) {
                    g2d.setColor(Color.BLACK);
                    int arrowX = x + boxSize + 2;
                    int arrowY = centerY + boxSize / 2;
                    g2d.drawLine(arrowX, arrowY, arrowX + spacing - 4, arrowY);
                    g2d.fillPolygon(
                            new int[]{arrowX + spacing - 4, arrowX + spacing - 8, arrowX + spacing - 8},
                            new int[]{arrowY, arrowY - 4, arrowY + 4},
                            3
                    );
                }
            }

            // Front label
            g2d.setColor(Color.BLUE);
            g2d.setFont(new Font("Arial", Font.BOLD, 14));
            g2d.drawString("FRONT", startX, centerY - 10);
            g2d.drawLine(startX + 25, centerY - 5, startX + 25, centerY);

            // Rear label
            int lastX = startX + (elements.length - 1) * (boxSize + spacing);
            g2d.setColor(Color.RED);
            g2d.drawString("REAR", lastX, centerY + boxSize + 25);
            g2d.drawLine(lastX + 20, centerY + boxSize + 10, lastX + 20, centerY + boxSize);

            // Size indicator
            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font("Arial", Font.BOLD, 16));
            g2d.drawString("Size: " + queue.size() + " / " + MAX_SIZE, 50, 50);
        }
    }
}
