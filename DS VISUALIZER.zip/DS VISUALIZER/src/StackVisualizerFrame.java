import javax.swing.*;
import java.awt.*;
import java.util.Stack;

public class StackVisualizerFrame extends JFrame {
    private Stack<Integer> stack;
    private StackPanel stackPanel;
    private JTextField inputField;
    private static final int MAX_SIZE = 10;

    public StackVisualizerFrame() {
        stack = new Stack<>();
        setTitle("Stack Operations Viewer ");
        setSize(800, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(240, 240, 245));

        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(147, 112, 219));
        JLabel titleLabel = new JLabel("Stack Operations (LIFO - Last In First Out)");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);

        // Visualization Panel
        stackPanel = new StackPanel();

        // Control Panel
        JPanel controlPanel = new JPanel();
        controlPanel.setBackground(new Color(240, 240, 245));
        controlPanel.setLayout(new GridLayout(2, 1, 5, 5));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Input Panel
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        inputPanel.setBackground(new Color(240, 240, 245));

        inputPanel.add(new JLabel("Value:"));
        inputField = new JTextField(10);
        inputPanel.add(inputField);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setBackground(new Color(240, 240, 245));

        JButton pushButton = createButton("Push (Insert)", new Color(60, 179, 113));
        pushButton.addActionListener(e -> push());

        JButton popButton = createButton("Pop (Remove)", new Color(220, 20, 60));
        popButton.addActionListener(e -> pop());

        JButton peekButton = createButton("Peek (View Top)", new Color(255, 140, 0));
        peekButton.addActionListener(e -> peek());

        JButton clearButton = createButton("Clear Stack", new Color(128, 128, 128));
        clearButton.addActionListener(e -> clear());

        JButton backButton = createButton("Back", new Color(105, 105, 105));
        backButton.addActionListener(e -> {
            LinearDSFrame linearFrame = new LinearDSFrame();
            linearFrame.setVisible(true);
            dispose();
        });

        buttonPanel.add(pushButton);
        buttonPanel.add(popButton);
        buttonPanel.add(peekButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(backButton);

        controlPanel.add(inputPanel);
        controlPanel.add(buttonPanel);

        add(titlePanel, BorderLayout.NORTH);
        add(stackPanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);
    }

    private JButton createButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        return button;
    }

    private void push() {
        try {
            if (stack.size() >= MAX_SIZE) {
                JOptionPane.showMessageDialog(this, "Stack Overflow! Maximum size is " + MAX_SIZE,
                        "Error Occur !", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int value = Integer.parseInt(inputField.getText().trim());
            stack.push(value);
            stackPanel.repaint();
            inputField.setText("");
            JOptionPane.showMessageDialog(this, "Pushed " + value + " onto stack");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid integer",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void pop() {
        if (stack.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Stack Underflow! Stack is empty",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int value = stack.pop();
        stackPanel.repaint();
        JOptionPane.showMessageDialog(this, "Popped " + value + " from stack");
    }

    private void peek() {
        if (stack.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Stack is empty",
                    "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int value = stack.peek();
        JOptionPane.showMessageDialog(this, "Top element: " + value);
    }

    private void clear() {
        stack.clear();
        stackPanel.repaint();
        JOptionPane.showMessageDialog(this, "Stack cleared");
    }

    class StackPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            setBackground(Color.WHITE);

            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int boxWidth = 150;
            int boxHeight = 50;
            int centerX = getWidth() / 2 - boxWidth / 2;
            int startY = getHeight() - 100;

            if (stack.isEmpty()) {
                g2d.setColor(Color.GRAY);
                g2d.setFont(new Font("Arial", Font.ITALIC, 18));
                g2d.drawString("Stack is empty. Push elements to see them .", 220, 250);

                // Draw empty stack base
                g2d.setColor(new Color(200, 200, 200));
                g2d.fillRect(centerX, startY, boxWidth, boxHeight);
                g2d.setColor(Color.BLACK);
                g2d.drawRect(centerX, startY, boxWidth, boxHeight);
                g2d.drawString("Bottom", centerX + 45, startY + 32);
                return;
            }

            // Draw stack elements from bottom to top
            for (int i = 0; i < stack.size(); i++) {
                int y = startY - (i * boxHeight);

                // Color gradient for better visualization
                int colorValue = 147 + (i * 10);
                if (colorValue > 220) colorValue = 220;
                g2d.setColor(new Color(colorValue, 112, 219));
                g2d.fillRect(centerX, y, boxWidth, boxHeight);

                // Border
                g2d.setColor(Color.BLACK);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawRect(centerX, y, boxWidth, boxHeight);

                // Value
                g2d.setColor(Color.WHITE);
                g2d.setFont(new Font("Arial", Font.BOLD, 20));
                String value = String.valueOf(stack.get(i));
                FontMetrics fm = g2d.getFontMetrics();
                int textX = centerX + (boxWidth - fm.stringWidth(value)) / 2;
                int textY = y + (boxHeight + fm.getAscent()) / 2 - 2;
                g2d.drawString(value, textX, textY);

                // Label for top element
                if (i == stack.size() - 1) {
                    g2d.setColor(Color.RED);
                    g2d.setFont(new Font("Arial", Font.BOLD, 14));
                    g2d.drawString("← TOP", centerX + boxWidth + 10, y + boxHeight / 2 + 5);
                }

                // Label for bottom element
                if (i == 0) {
                    g2d.setColor(Color.BLUE);
                    g2d.setFont(new Font("Arial", Font.BOLD, 14));
                    g2d.drawString("← BOTTOM", centerX + boxWidth + 10, y + boxHeight / 2 + 5);
                }
            }

            // Draw size indicator
            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font("Arial", Font.BOLD, 16));
            g2d.drawString("Size: " + stack.size() + " / " + MAX_SIZE, 50, 50);
        }
    }
}
