import javax.swing.*;
import java.awt.*;
import java.util.*;

public class TreeVisualizerFrame extends JFrame {
    private TreeNode root;
    private TreePanel treePanel;
    private JTextField inputField;

    public TreeVisualizerFrame() {
        root = null;
        setTitle("Binary Search Tree Operations Visualizer");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(240, 240, 245));

        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(34, 139, 34));
        JLabel titleLabel = new JLabel("Binary Search Tree Operations");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);

        // Visualization Panel
        treePanel = new TreePanel();

        // Control Panel
        JPanel controlPanel = new JPanel();
        controlPanel.setBackground(new Color(240, 240, 245));
        controlPanel.setLayout(new GridLayout(2, 1, 5, 5));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Input Panel
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        inputPanel.setBackground(new Color(240, 240, 245));

        inputPanel.add(new JLabel("Value:"));
        inputField = new JTextField(10);
        inputPanel.add(inputField);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setBackground(new Color(240, 240, 245));

        JButton insertButton = createButton("Insert", new Color(60, 179, 113));
        insertButton.addActionListener(e -> insert());

        JButton deleteButton = createButton("Delete", new Color(220, 20, 60));
        deleteButton.addActionListener(e -> delete());

        JButton searchButton = createButton("Search", new Color(255, 140, 0));
        searchButton.addActionListener(e -> search());

        JButton inorderButton = createButton("Inorder", new Color(70, 130, 180));
        inorderButton.addActionListener(e -> displayTraversal("Inorder", inorderTraversal()));

        JButton preorderButton = createButton("Preorder", new Color(147, 112, 219));
        preorderButton.addActionListener(e -> displayTraversal("Preorder", preorderTraversal()));

        JButton postorderButton = createButton("Postorder", new Color(255, 99, 71));
        postorderButton.addActionListener(e -> displayTraversal("Postorder", postorderTraversal()));

        JButton clearButton = createButton("Clear Tree", new Color(128, 128, 128));
        clearButton.addActionListener(e -> clear());

        JButton backButton = createButton("Back", new Color(105, 105, 105));
        backButton.addActionListener(e -> {
            NonLinearDSFrame nonLinearFrame = new NonLinearDSFrame();
            nonLinearFrame.setVisible(true);
            dispose();
        });

        buttonPanel.add(insertButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(searchButton);
        buttonPanel.add(inorderButton);
        buttonPanel.add(preorderButton);
        buttonPanel.add(postorderButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(backButton);

        controlPanel.add(inputPanel);
        controlPanel.add(buttonPanel);

        add(titlePanel, BorderLayout.NORTH);
        add(treePanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);
    }

    private JButton createButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 11));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        return button;
    }

    private void insert() {
        try {
            int value = Integer.parseInt(inputField.getText().trim());
            root = insertNode(root, value);
            treePanel.repaint();
            inputField.setText("");
            JOptionPane.showMessageDialog(this, "Inserted " + value + " into the tree");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid integer",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private TreeNode insertNode(TreeNode node, int value) {
        if (node == null) {
            return new TreeNode(value);
        }

        if (value < node.value) {
            node.left = insertNode(node.left, value);
        } else if (value > node.value) {
            node.right = insertNode(node.right, value);
        } else {
            JOptionPane.showMessageDialog(this, "Value already exists in tree");
        }

        return node;
    }

    private void delete() {
        try {
            int value = Integer.parseInt(inputField.getText().trim());
            if (searchNode(root, value)) {
                root = deleteNode(root, value);
                treePanel.repaint();
                inputField.setText("");
                JOptionPane.showMessageDialog(this, "Deleted " + value + " from the tree");
            } else {
                JOptionPane.showMessageDialog(this, value + " not found in tree");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid integer",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private TreeNode deleteNode(TreeNode node, int value) {
        if (node == null) return null;

        if (value < node.value) {
            node.left = deleteNode(node.left, value);
        } else if (value > node.value) {
            node.right = deleteNode(node.right, value);
        } else {
            if (node.left == null) return node.right;
            if (node.right == null) return node.left;

            TreeNode minNode = findMin(node.right);
            node.value = minNode.value;
            node.right = deleteNode(node.right, minNode.value);
        }

        return node;
    }

    private TreeNode findMin(TreeNode node) {
        while (node.left != null) {
            node = node.left;
        }
        return node;
    }

    private void search() {
        try {
            int value = Integer.parseInt(inputField.getText().trim());
            boolean found = searchNode(root, value);

            if (found) {
                JOptionPane.showMessageDialog(this, value + " found in the tree");
            } else {
                JOptionPane.showMessageDialog(this, value + " not found in the tree");
            }
            inputField.setText("");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid integer",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean searchNode(TreeNode node, int value) {
        if (node == null) return false;
        if (node.value == value) return true;
        return value < node.value ? searchNode(node.left, value) : searchNode(node.right, value);
    }

    private String inorderTraversal() {
        StringBuilder sb = new StringBuilder();
        inorder(root, sb);
        return sb.length() > 0 ? sb.toString() : "Tree is empty";
    }

    private void inorder(TreeNode node, StringBuilder sb) {
        if (node != null) {
            inorder(node.left, sb);
            sb.append(node.value).append(" ");
            inorder(node.right, sb);
        }
    }

    private String preorderTraversal() {
        StringBuilder sb = new StringBuilder();
        preorder(root, sb);
        return sb.length() > 0 ? sb.toString() : "Tree is empty";
    }

    private void preorder(TreeNode node, StringBuilder sb) {
        if (node != null) {
            sb.append(node.value).append(" ");
            preorder(node.left, sb);
            preorder(node.right, sb);
        }
    }

    private String postorderTraversal() {
        StringBuilder sb = new StringBuilder();
        postorder(root, sb);
        return sb.length() > 0 ? sb.toString() : "Tree is empty";
    }

    private void postorder(TreeNode node, StringBuilder sb) {
        if (node != null) {
            postorder(node.left, sb);
            postorder(node.right, sb);
            sb.append(node.value).append(" ");
        }
    }

    private void displayTraversal(String type, String result) {
        JOptionPane.showMessageDialog(this, type + " Traversal:\n" + result,
                type + " Traversal", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clear() {
        root = null;
        treePanel.repaint();
        JOptionPane.showMessageDialog(this, "Tree cleared");
    }

    class TreeNode {
        int value;
        TreeNode left, right;

        TreeNode(int value) {
            this.value = value;
            this.left = null;
            this.right = null;
        }
    }

    class TreePanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            setBackground(Color.WHITE);

            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (root == null) {
                g2d.setColor(Color.GRAY);
                g2d.setFont(new Font("Arial", Font.ITALIC, 18));
                g2d.drawString("Tree is empty. Insert elements to visualize.", 250, 300);
                return;
            }

            drawTree(g2d, root, getWidth() / 2, 50, getWidth() / 4);
        }

        private void drawTree(Graphics2D g2d, TreeNode node, int x, int y, int xOffset) {
            if (node == null) return;

            int nodeRadius = 25;

            // Draw edges to children first
            if (node.left != null) {
                int childX = x - xOffset;
                int childY = y + 80;
                g2d.setColor(Color.BLACK);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawLine(x, y + nodeRadius, childX, childY - nodeRadius);
                drawTree(g2d, node.left, childX, childY, xOffset / 2);
            }

            if (node.right != null) {
                int childX = x + xOffset;
                int childY = y + 80;
                g2d.setColor(Color.BLACK);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawLine(x, y + nodeRadius, childX, childY - nodeRadius);
                drawTree(g2d, node.right, childX, childY, xOffset / 2);
            }

            // Draw node
            g2d.setColor(new Color(34, 139, 34));
            g2d.fillOval(x - nodeRadius, y - nodeRadius, nodeRadius * 2, nodeRadius * 2);
            g2d.setColor(Color.BLACK);
            g2d.setStroke(new BasicStroke(2));
            g2d.drawOval(x - nodeRadius, y - nodeRadius, nodeRadius * 2, nodeRadius * 2);

            // Draw value
            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Arial", Font.BOLD, 16));
            String value = String.valueOf(node.value);
            FontMetrics fm = g2d.getFontMetrics();
            int textX = x - fm.stringWidth(value) / 2;
            int textY = y + fm.getAscent() / 2 - 2;
            g2d.drawString(value, textX, textY);
        }
    }
}